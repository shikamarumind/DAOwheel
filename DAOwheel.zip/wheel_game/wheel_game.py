from iconservice import *

TAG = 'Wheel'
LOOP = 1000000000000000000
BET_MIN = 0.1 * LOOP
BET_MAX = 100 * LOOP
BONUS_BET = 1 * LOOP

bet_types = ['MONKEY', 'SLOTH', 'JAGUAR', 'TOUCAN', 'IGUANA']
bonus_bet_types = ['FROG', 'TIGER']
bet_multipliers = {'MONKEY': 1, 'SLOTH': 2, 'JAGUAR': 5, 'TOUCAN': 10, 'IGUANA': 20, 'FROG': 0, 'TIGER': 0}
bonus_multipliers = {'5': 5, '10': 10, '15': 15, '25': 25, '50': 50, '250': 250, 'JACKPOT': 0}

# An interface to roulette score
class RouletteInterface(InterfaceScore):
    @interface
    def get_treasury_min(self) -> int:
        pass

    @interface
    def take_wager(self, _amount: int) -> None:
        pass

    @interface
    def wager_payout(self, _payout: int) -> None:
        pass

class Wheel(IconScoreBase):
    _GAME_ON = 'game_on'
    _ROULETTE_SCORE = 'roulette_score'
    ALL_PLAYERS_STRING = 'all_players_string'
    PLAYERS_BONUS_SPINS = 'players_bonus_spins'
    FROG_JACKPOT = 'frog_jackpot'
    TIGER_JACKPOT = 'tiger_jackpot'

    def __init__(self, db: IconScoreDatabase) -> None:
        super().__init__(db)
        self._game_on = VarDB(self._GAME_ON, db, value_type=bool)
        self._roulette_score = VarDB(self._ROULETTE_SCORE, db, value_type=Address)
        self.all_players_string = VarDB(self.ALL_PLAYERS_STRING, db, value_type=str)
        self.players_bonus_spins = DictDB(self.PLAYERS_BONUS_SPINS, db, value_type=str, depth=2)
        self.frog_jackpot = VarDB(self.FROG_JACKPOT, db, value_type=int)
        self.tiger_jackpot = VarDB(self.TIGER_JACKPOT, db, value_type=int)

    def on_install(self) -> None:
        super().on_install()
        self.frog_jackpot.set(0)
        self.tiger_jackpot.set(0)

    def on_update(self) -> None:
        super().on_update()

    @eventlog(indexed=1)
    def SpinResult(self, result: str):
        pass

    @eventlog(indexed=1)
    def TotalPayoutAmount(self, payout: str):
        pass

    @eventlog(indexed=2)
    def FundTransfer(self, recipient: Address, amount: int, note: str):
        pass

    @eventlog(indexed=1)
    def DEBUG(self, note: str):
        pass

    @external
    def set_roulette_score(self, _scoreAddress: Address) -> None:
        if self.msg.sender != self.owner:
            revert('Only the owner can call the set_roulette_score method')
        self._roulette_score.set(_scoreAddress)

    @external(readonly=True)
    def get_roulette_score(self) -> Address:
        return self._roulette_score.get()

    @external
    def toggle_game_status(self) -> None:
        if self.msg.sender != self.owner:
            revert('Only the owner can call the game_on method')
        if self._roulette_score.get() is not None:
            self._game_on.set(not self._game_on.get())

    @external(readonly=True)
    def get_game_status(self) -> bool:
        return self._game_on.get()

    @external(readonly=True)
    def get_score_owner(self) -> Address:
        return self.owner

    @external(readonly=True)
    def get_frog_jackpot_size(self) -> int:
        return self.frog_jackpot.get()

    @external(readonly=True)
    def get_tiger_jackpot_size(self) -> int:
        return self.tiger_jackpot.get()

    def get_random(self, user_seed: str = '') -> int:
        Logger.debug(f'Entered get_random.', TAG)
        seed = (str(bytes.hex(self.tx.hash)) + str(self.now()) + user_seed)
        spin = int.from_bytes(sha3_256(seed.encode()), "big")
        Logger.debug(f'Result of the spin was {spin}.', TAG)
        return spin

    def get_result(self, spin: int) -> str:
        result = ""
        random_number = spin % 54
        if 0 <= random_number <= 23:
            result = "MONKEY"
        elif 24 <= random_number <= 38:
            result = "SLOTH"
        elif 39 <= random_number <= 45:
            result = "JAGUAR"
        elif 46 <= random_number <= 49:
            result = "TOUCAN"
        elif 50 <= random_number <= 51:
            result = "IGUANA"
        elif random_number == 52:
            result = "FROG"
        elif random_number == 53:
            result = "TIGER"
        self.SpinResult(result)
        return result

    def get_bonus_result(self, spin: int) -> str:
        result = ""
        random_number = spin % 54
        if 0 <= random_number <= 23:
            result = "5"
        elif 24 <= random_number <= 38:
            result = "10"
        elif 39 <= random_number <= 45:
            result = "15"
        elif 46 <= random_number <= 49:
            result = "25"
        elif 50 <= random_number <= 51:
            result = "50"
        elif random_number == 52:
            result = "250"
        elif random_number == 53:
            result = "JACKPOT"
        self.SpinResult(result)
        return result

    def get_multiplier(self, result: str) -> int:
        multiplier = bet_multipliers[result]
        return multiplier

    def get_bonus_multiplier(self, result: str) -> int:
        multiplier = bonus_multipliers[result]
        return multiplier

    @payable
    @external
    def bet(self, MONKEY: int, SLOTH: int, JAGUAR: int, TOUCAN: int, IGUANA: int, FROG: int, TIGER: int, user_seed: str = '') -> None:
        if str(self.tx.origin) not in self.all_players_string.get():
            self.all_players_string.set(self.all_players_string.get() + str(self.tx.origin) + ",")
            self.players_bonus_spins[str(self.tx.origin)]["FROG"] = "0"
            self.players_bonus_spins[str(self.tx.origin)]["TIGER"] = "0"
        bonusCheck = self.check_for_bonus(str(self.tx.origin))
        if bonusCheck == True:
            revert(f'You have a bonus spin to use! Please spin the bonus wheel before placing a main bet.')
        bet_amount = {'MONKEY': MONKEY, 'SLOTH': SLOTH, 'JAGUAR': JAGUAR, 'TOUCAN': TOUCAN, 'IGUANA': IGUANA,
                      'FROG': FROG, 'TIGER': TIGER}
        total_bet_amount = 0
        for i in bet_types:
            if not (0 <= bet_amount[i] <= BET_MAX):
                Logger.debug(f'Bet placed out of range numbers', TAG)
                revert(f'Invalid bet amount {bet_amount[i] / LOOP}. Choose a number between 0 to 100')
            total_bet_amount += bet_amount[i]
        for j in bonus_bet_types:
            if not (bet_amount[j] == BONUS_BET):
                Logger.debug(f'Bet placed incorrect amount.', TAG)
                revert(f'Invalid bet amount {bet_amount[j] / LOOP}. Bonus bet must equal 1.')
            total_bet_amount += bet_amount[j]
        if not self._game_on.get():
            Logger.debug(f'Game not active yet.', TAG)
            revert(f'Game not active yet.')
        if not BET_MIN <= total_bet_amount <= BET_MAX:
            Logger.debug(f'Betting amount {total_bet_amount / LOOP} out of range.', TAG)
            revert(f'Main bet amount {total_bet_amount / LOOP} out of range ({BET_MIN / LOOP} ,{BET_MAX / LOOP}).')
        if not total_bet_amount == self.msg.value:
            Logger.debug(f'Invalid bet. Total bet value must equal Total bet amount', TAG)
            revert(f'Total Bet amount {total_bet_amount / LOOP} doesnt equal Total bet Value {self.msg.value / LOOP} ')

        # Get random spin number.
        spin = self.get_random(user_seed)

        # Get the result of the wheel spin.
        result = self.get_result(spin)
        if result == "FROG" and bet_amount[result] > 0:
            self.players_bonus_spins[str(self.tx.origin)]["FROG"] = \
                str(int(self.players_bonus_spins[str(self.tx.origin)]["FROG"]) + 1)
        elif result == "TIGER" and bet_amount[result] > 0:
            self.players_bonus_spins[str(self.tx.origin)]["TIGER"] = \
                str(int(self.players_bonus_spins[str(self.tx.origin)]["TIGER"]) + 1)

        # Get the multiplier for the winning result.
        multiplier = self.get_multiplier(result)

        # Determine the payout to the player.
        payout = 0
        take_wager_amount = 0
        payout += bet_amount[result] + (multiplier * bet_amount[result])
        for i in bet_types:
            if i == result and bet_amount[result] > 0:
                take_wager_amount += bet_amount[result]
            else:
                take_wager_amount += int(bet_amount[i] * 0.9995)
                self.frog_jackpot.set(self.frog_jackpot.get() + int(bet_amount[i] * 0.00025))
                self.tiger_jackpot.set(self.tiger_jackpot.get() + int(bet_amount[i] * 0.00025))
        for j in bonus_bet_types:
            if j == result and bet_amount[result] > 0:
                take_wager_amount += bet_amount[result]
            else:
                take_wager_amount += int(bet_amount[j] * 0.2)
                self.frog_jackpot.set(self.frog_jackpot.get() + int(bet_amount[j] * 0.4))
                self.tiger_jackpot.set(self.tiger_jackpot.get() + int(bet_amount[j] * 0.4))
        if payout == 0:
            self._take_wager(take_wager_amount)
        else:
            self._take_wager_and_request_payout(take_wager_amount, payout)
        self.TotalPayoutAmount(str(payout / LOOP))

    def check_for_bonus(self, wallet_address: str) -> bool:
        frog_bonus = int(self.players_bonus_spins[wallet_address]["FROG"])
        tiger_bonus = int(self.players_bonus_spins[wallet_address]["TIGER"])
        self.DEBUG("FROG BONUS: " + str(frog_bonus))
        self.DEBUG("TIGER BONUS: " + str(tiger_bonus))
        if frog_bonus > 0 or tiger_bonus > 0:
            return True
        else:
            return False
        pass

    @external(readonly=True)
    def check_bonus(self, wallet_address: str) -> str:
        frog_bonus = int(self.players_bonus_spins[wallet_address]["FROG"])
        tiger_bonus = int(self.players_bonus_spins[wallet_address]["TIGER"])
        if frog_bonus > 0:
            return "FROG"
        elif tiger_bonus > 0:
            return "TIGER"
        else:
            return "NONE"

    @external
    def bonus_spin(self, user_seed: str = '') -> None:
        bonusCheck = self.check_for_bonus(str(self.tx.origin))
        if bonusCheck == False:
            revert(f'You do not have any bonus spins to use! Please place a main bet.')
        jackpotType = self.check_bonus(str(self.tx.origin))
        self.DEBUG("jackpotType: " + str(jackpotType))
        # Get random spin number.
        spin = self.get_random(user_seed)
        # Get the result of the wheel spin.
        result = self.get_bonus_result(spin)
        # Get the multiplier for the winning result.
        multiplier = self.get_bonus_multiplier(result)
        # Determine the payout to the player.
        if result != "JACKPOT":
            payout = 0
            payout += 1 * multiplier * LOOP
            self._request_payout(payout)
            self.TotalPayoutAmount(str(payout / LOOP))
        elif result == "JACKPOT":
            if jackpotType == "FROG":
                self.icx.transfer(self.tx.origin, self.frog_jackpot.get())
                self.TotalPayoutAmount(str(self.frog_jackpot.get()))
                self.frog_jackpot.set(0)
            elif jackpotType == "TIGER":
                self.icx.transfer(self.tx.origin, self.tiger_jackpot.get())
                self.TotalPayoutAmount(str(self.tiger_jackpot.get()))
                self.tiger_jackpot.set(0)
        self.players_bonus_spins[str(self.tx.origin)][jackpotType] = \
            str(int(self.players_bonus_spins[str(self.tx.origin)][jackpotType]) - 1)

    def _take_wager(self, _wager: int) -> None:
        try:
            self.icx.transfer(self._roulette_score.get(), _wager)
            self.FundTransfer(self._roulette_score.get(), _wager, "Sending icx to roulette")
            roulette_score = self.create_interface_score(self._roulette_score.get(), RouletteInterface)
            roulette_score.take_wager(_wager)
        except BaseException as e:
            revert('Network problem. Winnings not sent. Will try again. '
                   f'Exception: {e}')

    def _take_wager_and_request_payout(self, _wager: int, _payout: int) -> None:
        try:
            self.icx.transfer(self._roulette_score.get(), _wager)
            self.FundTransfer(self._roulette_score.get(), _wager, "Sending icx to roulette")
            roulette_score = self.create_interface_score(self._roulette_score.get(), RouletteInterface)
            roulette_score.take_wager(_wager)
            roulette_score.wager_payout(_payout)
        except BaseException as e:
            revert('Network problem. Winnings not sent. Will try again. '
                   f'Exception: {e}')

    def _request_payout(self, _payout: int) -> None:
        try:
            roulette_score = self.create_interface_score(self._roulette_score.get(), RouletteInterface)
            roulette_score.wager_payout(_payout)
        except BaseException as e:
            revert('Network problem. Winnings not sent. Will try again. '
                   f'Exception: {e}')

    @payable
    def fallback(self):
        pass