from iconservice import *

TAG = 'Wheel'
LOOP = 1000000000000000000
BET_MIN = 0.1 * LOOP
BET_MAX = 100 * LOOP

bet_types = ['1', '2', '5', '10', '20', 'MIN', 'GEO']
bet_multipliers = {'1': 1, '2': 2, '5': 5, '10': 10, '20': 20, 'MIN': 40, 'GEO': 40}

# An interface to roulette score
class RouletteInterface(InterfaceScore):
    @interface
    def get_treasury_min(self) -> int:
        pass

    @interface
    def take_wager(self, _amount: int) -> None:
        pass

    @interface
    def wager_payout(self, _payout: int) -> None:
        pass

class Wheel(IconScoreBase):
    _GAME_ON = "game_on"
    _ROULETTE_SCORE = 'roulette_score'

    def __init__(self, db: IconScoreDatabase) -> None:
        super().__init__(db)
        self._game_on = VarDB(self._GAME_ON, db, value_type=bool)
        self._roulette_score = VarDB(self._ROULETTE_SCORE, db, value_type=Address)

    def on_install(self) -> None:
        super().on_install()

    def on_update(self) -> None:
        super().on_update()

    @eventlog(indexed=1)
    def SpinResult(self, result: str):
        pass

    @eventlog(indexed=1)
    def TotalPayoutAmount(self, payout: str):
        pass

    @eventlog(indexed=2)
    def FundTransfer(self, recipient: Address, amount: int, note: str):
        pass

    @external
    def set_roulette_score(self, _scoreAddress: Address) -> None:
        if self.msg.sender != self.owner:
            revert('Only the owner can call the set_roulette_score method')
        self._roulette_score.set(_scoreAddress)

    @external(readonly=True)
    def get_roulette_score(self) -> Address:
        return self._roulette_score.get()

    @external
    def toggle_game_status(self) -> None:
        if self.msg.sender != self.owner:
            revert('Only the owner can call the game_on method')
        if self._roulette_score.get() is not None:
            self._game_on.set(not self._game_on.get())

    @external(readonly=True)
    def get_game_status(self) -> bool:
        return self._game_on.get()

    @external(readonly=True)
    def get_score_owner(self) -> Address:
        return self.owner

    def get_random(self, user_seed: str = '') -> int:
        Logger.debug(f'Entered get_random.', TAG)
        seed = (str(bytes.hex(self.tx.hash)) + str(self.now()) + user_seed)
        spin = int.from_bytes(sha3_256(seed.encode()), "big")
        Logger.debug(f'Result of the spin was {spin}.', TAG)
        return spin

    def get_result(self, spin: int) -> str:
        result = ""
        random_number = spin % 54
        if 0 <= random_number <= 23:
            result = "1"
        elif 24 <= random_number <= 38:
            result = "2"
        elif 39 <= random_number <= 45:
            result = "5"
        elif 46 <= random_number <= 49:
            result = "10"
        elif 50 <= random_number <= 51:
            result = "20"
        elif random_number == 52:
            result = "MIN"
        elif random_number == 53:
            result = "GEO"
        self.SpinResult(result)
        return result

    def get_multiplier(self, result: str) -> int:
        multiplier = bet_multipliers[result]
        return multiplier

    @payable
    @external
    def bet(self, ONE: int, TWO: int, FIVE: int, TEN: int, TWENTY: int, MIN: int, GEO: int, user_seed: str = '') -> None:
        bet_amount = {'1': ONE, '2': TWO, '5': FIVE, '10': TEN, '20': TWENTY, 'MIN': MIN, 'GEO': GEO}
        total_bet_amount = 0
        for i in bet_types:
            if not (0 <= bet_amount[i] <= BET_MAX):
                Logger.debug(f'Bet placed out of range numbers', TAG)
                revert(f'Invalid bet amount {bet_amount[i] / LOOP}. Choose a number between 0 to 100')
            total_bet_amount += bet_amount[i]
        if not self._game_on.get():
            Logger.debug(f'Game not active yet.', TAG)
            revert(f'Game not active yet.')
        if not BET_MIN <= total_bet_amount <= BET_MAX:
            Logger.debug(f'Betting amount {total_bet_amount / LOOP} out of range.', TAG)
            revert(f'Main bet amount {total_bet_amount / LOOP} out of range ({BET_MIN / LOOP} ,{BET_MAX / LOOP}).')
        if not total_bet_amount == self.msg.value:
            Logger.debug(f'Invalid bet. Total bet value must equal Total bet amount', TAG)
            revert(f'Total Bet amount {total_bet_amount / LOOP} doesnt equal Total bet Value {self.msg.value / LOOP} ')

        # Get random spin number.
        spin = self.get_random(user_seed)

        # Get the result of the wheel spin.
        result = self.get_result(spin)

        # Get the multiplier for the winning result.
        multiplier = self.get_multiplier(result)

        # Determine the payout to the player.
        payout = 0
        payout += bet_amount[result] + (multiplier * bet_amount[result])
        if payout == 0:
            self._take_wager(total_bet_amount)
        else:
            self._take_wager_and_request_payout(total_bet_amount, payout)
        self.TotalPayoutAmount(str(payout / LOOP))

    def _take_wager(self, _wager: int):
        try:
            self.icx.transfer(self._roulette_score.get(), _wager)
            self.FundTransfer(self._roulette_score.get(), _wager, "Sending icx to roulette")
            roulette_score = self.create_interface_score(self._roulette_score.get(), RouletteInterface)
            roulette_score.take_wager(_wager)
        except BaseException as e:
            revert('Network problem. Winnings not sent. Will try again. '
                   f'Exception: {e}')

    def _take_wager_and_request_payout(self, _wager: int, _payout: int):
        try:
            self.icx.transfer(self._roulette_score.get(), _wager)
            self.FundTransfer(self._roulette_score.get(), _wager, "Sending icx to roulette")
            roulette_score = self.create_interface_score(self._roulette_score.get(), RouletteInterface)
            roulette_score.take_wager(_wager)
            roulette_score.wager_payout(_payout)
        except BaseException as e:
            revert('Network problem. Winnings not sent. Will try again. '
                   f'Exception: {e}')

    @payable
    def fallback(self):
        pass